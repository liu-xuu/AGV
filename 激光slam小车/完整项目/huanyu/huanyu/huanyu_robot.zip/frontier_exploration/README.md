# frontier_exploration
ROS Node and Costmap 2D plugin layer for frontier exploration

See http://wiki.ros.org/frontier_exploration
